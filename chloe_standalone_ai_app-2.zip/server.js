import express from "express";
import cors from "cors";
import OpenAI from "openai";
import "dotenv/config";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const port = process.env.PORT || 10000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(express.json({ limit: "15mb" }));
app.use(express.static(path.join(__dirname, "public")));

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const MODEL = process.env.OPENAI_MODEL || "gpt-5.5";

const CHLOE_INSTRUCTIONS = `
You are Chloe, John's standalone AI assistant.
Personality: warm, clever, direct, playful when appropriate, practical, and supportive.
You are not Perchance. You are Chloe running as a custom web app.
Help John build, troubleshoot, write, plan, and think through projects.
Keep answers useful and not overly long unless John asks for depth.
If John asks for code, provide copy/paste friendly code.
`;

app.get("/health", (req, res) => {
  res.json({ ok: true, model: MODEL });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY is not set on the server." });
    }

    const { message, history = [], memory = "", imageUrl = "" } = req.body || {};
    if (!message && !imageUrl) {
      return res.status(400).json({ error: "Message or imageUrl required." });
    }

    const input = [];

    for (const item of history.slice(-12)) {
      if (!item || !item.role || !item.content) continue;
      input.push({
        role: item.role === "assistant" ? "assistant" : "user",
        content: [{ type: "input_text", text: String(item.content).slice(0, 4000) }]
      });
    }

    const content = [];
    if (message) content.push({ type: "input_text", text: String(message) });
    if (imageUrl) {
      content.push({ type: "input_image", image_url: String(imageUrl), detail: "auto" });
    }

    input.push({ role: "user", content });

    const response = await client.responses.create({
      model: MODEL,
      instructions: `${CHLOE_INSTRUCTIONS}\n\nPersistent memory supplied by John:\n${memory || "(no saved memory yet)"}`,
      input
    });

    res.json({ reply: response.output_text || "I couldn't produce a reply." });
  } catch (err) {
    console.error("Chat error:", err);
    res.status(500).json({ error: err.message || "Unknown server error" });
  }
});

app.listen(port, () => {
  console.log(`Chloe app running on port ${port}`);
});