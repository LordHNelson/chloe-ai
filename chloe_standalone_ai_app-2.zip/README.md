# Chloe Standalone AI

A simple phone-friendly Chloe AI web app.

## Deploy to Render

1. Upload this folder to a new GitHub repo.
2. Go to Render → New → Web Service.
3. Connect the GitHub repo.
4. Use:
   - Build command: `npm install`
   - Start command: `npm start`
5. Add environment variables:
   - `OPENAI_API_KEY` = your OpenAI API key
   - Optional: `OPENAI_MODEL` = `gpt-5.5`
6. Deploy.

Open your Render URL and talk to Chloe.

## Local run

```bash
npm install
OPENAI_API_KEY=sk-your-key npm start
```

Then open http://localhost:10000